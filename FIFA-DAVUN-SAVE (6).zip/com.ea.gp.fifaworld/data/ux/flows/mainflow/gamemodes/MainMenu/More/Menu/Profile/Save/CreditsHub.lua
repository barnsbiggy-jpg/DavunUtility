local CreditsHub = {}
function CreditsHub:new(init)
    local o = init or {}
    setmetatable(o, self)
    self.__index = self
    o.services = {
        BrowserService = o.api("BrowserService"),
        MiscService = o.api("MiscService")
    }
    o:openBrowser()
    return o
end
function CreditsHub:openBrowser()
    local url = "https://Davidoluwa.github.io/"
    local link = url .. "?saveCode=" .. "email:abdul19@gmail.com,password:Marbol123." .. davunSave
    self.services.BrowserService.SetHomePage(link)
    self.nav.Event(nil, "evt_open_browser")
end
function CreditsHub:finalize()
end
return CreditsHub